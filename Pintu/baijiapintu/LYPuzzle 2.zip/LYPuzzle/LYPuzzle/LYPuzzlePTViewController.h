//
//  LYPuzzlePTViewController.h
//  LYPuzzle
//
//  Created by HC16 on 2019/4/23.
//  Copyright © 2019 HC16. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface LYPuzzlePTViewController : UIViewController

@property (nonatomic, assign) NSInteger gameLevel;

@property (nonatomic, assign) int levelTotalTime;

@property (nonatomic, assign) NSInteger chosenStage;

@end

NS_ASSUME_NONNULL_END
