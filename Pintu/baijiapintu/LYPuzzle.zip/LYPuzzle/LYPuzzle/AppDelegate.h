//
//  AppDelegate.h
//  LYPuzzle
//
//  Created by HC16 on 2019/4/16.
//  Copyright © 2019 HC16. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

