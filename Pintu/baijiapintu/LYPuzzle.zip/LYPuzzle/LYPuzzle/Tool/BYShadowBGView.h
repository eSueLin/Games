//
//  BYShadowBGView.h
//  BMPintu
//
//  Created by HC16 on 2019/4/12.
//  Copyright © 2019 BirdMichael. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface BYShadowBGView : UIView

@end

NS_ASSUME_NONNULL_END
