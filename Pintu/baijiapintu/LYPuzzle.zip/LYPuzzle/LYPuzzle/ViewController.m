//
//  ViewController.m
//  LYPuzzle
//
//  Created by HC16 on 2019/4/16.
//  Copyright © 2019 HC16. All rights reserved.
//

#import "ViewController.h"
#import "LYPuzzlePTViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}


- (IBAction)btntoClick:(id)sender {

    UIButton *btn = (UIButton *)sender;
    
    NSString *plistPath = [[NSBundle mainBundle] pathForResource:@"LevelTime" ofType:@"plist"];
    NSDictionary *plistDict = [NSDictionary dictionaryWithContentsOfFile:plistPath];
   
    NSDictionary *tagDic = [plistDict valueForKey:[NSString stringWithFormat:@"%ld", btn.tag]];
    NSInteger level = [tagDic[@"level"] integerValue];
    int time = [tagDic[@"time"] intValue];
    
    LYPuzzlePTViewController *ptvc = [[LYPuzzlePTViewController alloc] initWithNibName:@"LYPuzzlePTViewController" bundle:nil];
    ptvc.levelTotalTime = time;
    ptvc.gameLevel = level;
    
    [self presentViewController:ptvc animated:YES completion:nil];
}


@end
